export const OTM_KEY = "5ae2e3f221c38a28845f05b61368fdba29df000dd0262e1c07e923b3"; // OpenTripMap key
export const GEOAPIFY_KEY = "05d17806f3e34c57ab28c7a41c06ba4e"; // Geoapify key
